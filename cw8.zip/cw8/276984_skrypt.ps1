﻿#Bazy Danych Przestrzennych, ćwiczenia 8-9, automatyzacja przetwarzania
#Data utworzenia: 30.12.2021

$lokalizacja = "C:\Users\Agnieszka\desktop\bazy_powershell"
Set-Location "$lokalizacja"
${NUMERINDEKSU} = "276984"
${TIMESTAMP} = "{0:MMddyyy}" -f (Get-Date)
${TIMESTAMP2} = "{0:MMddyyy_HHmmss}" -f (Get-Date)

#UTWORZENIE PLIKU LOG
$log = "$lokalizacja\${NUMERINDEKSU}_${TIMESTAMP}.log"

try 
{
    "BAZY DANYCH PRZESTRZENNYCH - ĆWICZENIE 8-9 - AUTOMATYZACJA PRZETWARZANIA" >> $log

    #DANE WEJŚCIOWE
    $adresPliku = "https://home.agh.edu.pl/~wsarlej/Customers_Nov2021.zip"
    $hasloPlik = "agh"

    #DANE DO WYSYŁANIA MAILA
    $emailNadawca = "asolarz.bdp@gmail.com"
    $emailHaslo = "BazyDanych2"
    $emailOdbiorca = "agasol17@gmail.com"

    "${TIMESTAMP2} - Script open - Successful" >> $log

    #POBRANIE PLIKU
    try 
    {
        $lokalizacjaPliku = "$lokalizacja\Customers_Nov2021.zip"
        $webClient = New-Object System.Net.WebClient
        $webclient.DownloadFile($adresPliku,$lokalizacjaPliku)
        "${TIMESTAMP2} - File download - Successful" >> $log
    }
    catch
    {
        "${TIMESTAMP2} - File download - Unsuccessful" >> $log
    }

    #ROZPAKOWANIE PLIKU
    try 
    {
        $lokalizacjaUnzip = "C:\Program Files\7-Zip\7z.exe"
        Start-Process -FilePath $lokalizacjaUnzip -ArgumentList "x -o$lokalizacja $lokalizacjaPliku -p$hasloPlik" -Wait
        "${TIMESTAMP2} - Unzip file - Successful" >> $log
    }
    catch
    {
        "${TIMESTAMP2} - Unzip file - Unsuccessful" >> $log
    }

    #POPRAWNOŚĆ PLIKU
    try
    {
        #WCZYTANIE PLIKÓW
        $pobranyPlik = Get-Content "$lokalizacja\Customers_Nov2021.csv"
        $staryPlik = Get-Content "$lokalizacja\Customers_old.csv"
        "${TIMESTAMP2} - Load files - Successful" >> $log

        #ZLICZANIE WIERSZY
        $pobranyPlikWiersze = $pobranyPlik.Count- 1
        $duplikaty = 0

        #SZUKANIE WSPÓLNYCH REKORDÓW
        for ($i = 1; $i -lt $pobranyPlik.Count; $i++) {
            for ($j = 1; $j -lt $staryPlik.Count; $j++) {
                if ($pobranyPlik[$i] -eq $staryPlik[$j]) {
                    Add-Content -Path "$lokalizacja\Customers_Nov2021.bad_${TIMESTAMP}" -Value $pobranyPlik[$i]
                    $duplikaty = $duplikaty + 1
                    $pobranyPlik[$i] = ""
                }        
            }        
        }
        "${TIMESTAMP2} - Find duplicates - Successful" >> $log

        #USUNIĘCIE PUSTYCH LINII
        $wyczyszczonyPlik = for ($i = 0; $i -lt $pobranyPlik.Count; $i++) {
            if ($pobranyPlik[$i] -ne "" -and $pobranyPlik[$i] -ne ",,,,") {
                $pobranyPlik[$i]
            }
        }
        "${TIMESTAMP2} - Remove empty lines - Successful" >> $log

        $wyczyszczonyPlikWiersze = $wyczyszczonyPlik.Count - 1

        #ZAPIS POPRAWNEGO PLIKU DO CSV
        try
        {
            $wyczyszczonyPlik > "$lokalizacja\Customers_Nov2021.csv"
            "${TIMESTAMP2} - Correct file to CSV - Successful" >> $log
        }
        catch
        {
            "${TIMESTAMP2} - Correct file to CSV - Unsuccessful" >> $log
        }
    }
    catch
    {
        "${TIMESTAMP2} - Load files/Correct files - Unsuccessful" >> $log
    }

    #ŁĄCZENIE Z BAZĄ DANYCH
    try
    {
        #Install-Module PostgreSQLCmdlets -Scope CurrentUser
        Set-Location "C:\Program Files\PostgreSQL\13\bin\"

        $dburl="postgresql://postgres:postgresql@localhost:5433/automatyzacja"
        "${TIMESTAMP2} - Connect to PostgreSQL - Successful" >> $log

        try
        {
            #TWORZENIE TABELI
            $tabelaSQL = "CREATE TABLE IF NOT EXISTS CUSTOMERS_${NUMERINDEKSU} (first_name varchar(30), last_name varchar(30), email varchar(50), lat float, long float)" | .\psql --csv $dburl | ConvertFrom-Csv
        
            "${TIMESTAMP2} - Create table - Successful" >> $log
        }
        catch
        {
            "${TIMESTAMP2} - Create table - Unsuccessful or table already exists" >> $log
        }
        
        try
        {
            #WPISYWANIE DANYCH DO TABELI
            $daneTabelaWiersze = 0
            $plikSQL = Import-Csv "$lokalizacja\Customers_Nov2021.csv"
            for ($i = 1; $i -lt $plikSQL.Count; $i++) {
                $first_name = $plikSQL[$i].first_name
                $last_name = $plikSQL[$i].last_name
                $email = $plikSQL[$i].email
                $lat = $plikSQL[$i].lat
                $long = $plikSQL[$i].long
                $daneSQL = "INSERT INTO CUSTOMERS_${NUMERINDEKSU} (first_name, last_name, email, lat, long) VALUES ('$first_name', '$last_name', '$email', $lat, $long)" | .\psql --csv $dburl | ConvertFrom-Csv    
                $daneTabelaWiersze = $daneTabelaWiersze + 1
            }

            "${TIMESTAMP2} - Insert data - Successful" >> $log
        }
        catch
        {
            "${TIMESTAMP2} - Insert data - Unsuccessful" >> $log
        }       
    }
    catch
    {
        "${TIMESTAMP2} - Connect to PostgreSQL - Unsuccessful" >> $log
    }

    #PRZENIESIENIE PLIKU DO FOLDERU PROCESSED
    try
    {
        New-Item -Path "$lokalizacja\PROCESSED" -Force -ItemType Directory
        Move-Item -Path "$lokalizacja\Customers_Nov2021.csv" -Destination "$lokalizacja\PROCESSED\${TIMESTAMP}_Customers_Nov2021.csv"
        "${TIMESTAMP2} - File transfer - Successful" >> $log
    }
    catch
    {
        "${TIMESTAMP2} - File transfer - Unsuccessful" >> $log
    }

    #WYSŁANIE MAILA
    try
    {
        $emailTemat = "CUSTOMERS LOAD - ${TIMESTAMP}"
        $emailWiadomosc = "Liczba wierszy w pliku pobranym z interneu: $pobranyPlikWiersze `nLiczba poprawnych wierszy (po czyszczeniu): $wyczyszczonyPlikWiersze `nLiczba duplikatów w pliku wejściowym: $duplikaty `nIlość danych załadowanych do tabeli CUSTOMERS_${NUMERINDEKSU}: $daneTabelaWiersze"

        function Send-ToEmail([string]$email){

            $message = New-Object Net.Mail.MailMessage
            $message.From = "$Username"
            $message.To.Add("$emailOdbiorca")
            $message.Subject = $emailTemat
            $message.Body = $emailWiadomosc

            $smtp = New-Object Net.Mail.SmtpClient("smtp.gmail.com", "587")
            $smtp.EnableSSL = $true
            $smtp.Credentials = New-Object System.Net.NetworkCredential($emailNadawca, $emailHaslo)
            $smtp.send($message)
        }
        Send-ToEmail  -email $emailOdbiorca

        "${TIMESTAMP2} - Sending first email - Successful" >> $log
    }
    catch
    {
        "${TIMESTAMP2} - Sending first email - Unsuccessful" >> $log
    }

    try
    {
        #DODAWANIE ROZSZERZENIA POSTGIS
        $extensionSQL = "CREATE EXTENSION postgis" | .\psql --csv $dburl | ConvertFrom-Csv
        "${TIMESTAMP2} - Add extension postgis - Successful" >> $log
    }
    catch
    {
        "${TIMESTAMP2} - Add extension postgis - Unsuccessful or extension already exists" >> $log
    }

    try
    {
        #SZUKANIE KLIENTÓW W ODLEGLOSCI MNIEJSZEJ NIZ 50KM
        #$kwerendaSQL = "SELECT * FROM customers_276984 WHERE (ST_DISTANCE(ST_MakePoint(41.39988501005976, -75.67329768604034)::geography, ST_MakePoint(customers_276984.lat, customers_276984.long)::geography) < 50000)" | .\psql --csv $dburl | ConvertFrom-Csv 
        
        $kwerendaSQL = "SELECT * FROM customers_276984" | .\psql --csv $dburl | ConvertFrom-Csv
        "${TIMESTAMP2} - !!Different query used!! - SQL query - ST_Distance - Successful" >> $log
    }
    catch
    {
        "${TIMESTAMP2} - SQL query - ST_Distance - Unsuccessful" >> $log
    }

  
    #EKSPORT DO PLIKU CSV
    try
    {
        #wrong file - $wyczyszczonyPlik - plik wynikowy kwerendy

        $eksportNazwa = "BEST_CUSTOMERS_${NUMERINDEKSU}"
        $kwerendaSQL | Export-Csv -Path "$lokalizacja\BEST_CUSTOMERS_${NUMERINDEKSU}.csv" -NoTypeInformation

        $bestCustomersWiersze = Get-Content "$lokalizacja\BEST_CUSTOMERS_${NUMERINDEKSU}.csv"
        $bestCustomersWiersze = $bestCustomersWiersze.Count- 1

        $bestCustomersModyfikacja = Get-Item "$lokalizacja\BEST_CUSTOMERS_${NUMERINDEKSU}.csv" | Foreach {$_.LastWriteTime}
        "${TIMESTAMP2} - Export to CSV - Successful" >> $log
    }
    catch
    {
        "${TIMESTAMP2} - Export to CSV - Unsuccessful" >> $log
    }

    #KOMPRESJA PLIKU CSV
    try
    {
        Compress-Archive -Path "$lokalizacja\BEST_CUSTOMERS_${NUMERINDEKSU}.csv" -DestinationPath "$lokalizacja\BEST_CUSTOMERS_${NUMERINDEKSU}.zip" -Update
        "${TIMESTAMP2} - File compression - Successful" >> $log
    }
    catch
    {
        "${TIMESTAMP2} - File compression - Unsuccessful" >> $log
    }

    #WYSŁANIE MAILA Z ZAŁĄCZNIKIEM
    try
    {
        $emailTemat2 = "BEST_CUSTOMERS_${NUMERINDEKSU} - ${TIMESTAMP}"
        $emailWiadomosc2 = "Data ostatniej modyfikacji: $bestCustomersModyfikacja `nIlość wierszy w pliku BEST_CUSTOMERS_${NUMERINDEKSU}.csv: $bestCustomersWiersze"
        $emailZalacznik = "$lokalizacja\BEST_CUSTOMERS_${NUMERINDEKSU}.zip"

        function Send-ToEmail([string]$email, [string]$attachmentpath){

            $message = new-object Net.Mail.MailMessage
            $message.From = "$Username"
            $message.To.Add("$emailOdbiorca")
            $message.Subject = $emailTemat2
            $message.Body = $emailWiadomosc2
            $attachment = New-Object Net.Mail.Attachment($attachmentpath)
            $message.Attachments.Add($attachment)

            $smtp = new-object Net.Mail.SmtpClient("smtp.gmail.com", "587")
            $smtp.EnableSSL = $true
            $smtp.Credentials = New-Object System.Net.NetworkCredential($emailNadawca, $emailHaslo)
            $smtp.send($message)
         
            $attachment.Dispose()
        }
        Send-ToEmail  -email $emailOdbiorca -attachmentpath $emailZalacznik;
        "${TIMESTAMP2} - Sending second email - Successful" >> $log
    }
    catch
    {
        "${TIMESTAMP2} - Sending second email - Unsuccessful" >> $log
    }
    
    "${TIMESTAMP2} - Script finish  - Successful" >> $log
}
catch 
{
    "${TIMESTAMP2} - Script open - Unsuccessful" >> $log
}

New-Item -Path "$lokalizacja\PROCESSED" -Force -ItemType Directory
Move-Item -Path $log -Destination "$lokalizacja\PROCESSED\${NUMERINDEKSU}_${TIMESTAMP}.log"